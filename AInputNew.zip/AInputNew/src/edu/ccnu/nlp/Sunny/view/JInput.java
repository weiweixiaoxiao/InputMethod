package edu.ccnu.nlp.Sunny.view;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import java.io.IOException;

import edu.ccnu.nlp.Sunny.BiGram;

public class JInput extends JFrame implements ActionListener { 
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	int num = 10 ;
	 String str = new String();
	String[][] result;
	// Build buttons.
    JButton[] buttons = new JButton[num];
	// For cancel or reset.
    JButton calculate = new JButton("����");
    // Build the text field to show the result.
    JTextField display1 = new JTextField("");
    JTextField display2 = new JTextField("");
    JLabel label1=new JLabel("������ƴ�����ÿո񽫴���ֿ���");
	
    public void input() throws IOException {       
       @SuppressWarnings("unused")
	   Frame f = new Frame("�����");
       JPanel panel1 = new JPanel();       
       for(int i=0;i<num;i++){
    	  buttons[i] = new JButton("");
    	  panel1.add(buttons[i]);   
      	  buttons[i].addActionListener(this);
       }           
           	       	       	       
       JPanel panel2 = new JPanel(new BorderLayout());
       panel2.add("North", label1);
       panel2.add("Center", display1);
       panel2.add("East", calculate);
       panel2.add("South", display2);
  
       getContentPane().setLayout(new BorderLayout());
       getContentPane().add("North", panel2);
       getContentPane().add("Center", panel1);
       
       // Add listener for "reset" button.
       calculate.addActionListener(new ActionListener() {
    	   public void actionPerformed(ActionEvent e) {
    		   calculate_actionPerformed(e);
    		   }
    		   });
       
       // Add listener for "display" button.
       display1.addActionListener(this);
       // The "close" button "X".
       addWindowListener(new WindowCloser());       
    // Initialize the window size.
       this.setPreferredSize(new Dimension(500, 300));        
       this.setVisible(true);       
       //this.setSize(new Dimension(800, 600));  
       this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);  
       this.pack();           
    }
    
    
  //���� Add action listener for each digit & operator button.          
   //�������ʾ��button�� 
    public void imageShow(){
    	label1.setText("������£�");
    	label1.setFont(new Font("����", 0, 12));
    	label1.setForeground(Color.blue);
    	boolean t = false; 
    	if(result!=null){
     	   if(result.length<10){
     		   num = result.length;
     		   t = true;
     	   }
            for(int i=0;i<num;i++){
               int m = i+1;
     	       buttons[i].setText(m+result[i][0]);
     	       buttons[i].setFont(new Font("����", 0, 15));
     	   }  
           if(t){
        	   for(int i=result.length;i<10;i++){
        		   System.out.println("wefw");
        	       buttons[i].setText(" ");
        	   }  
           }
        }
    }

	public void conver() throws IOException{
    	String dis = display1.getText();    	
    	result = null;
    	//��ȡƴ�����
    	result = BiGram.biGram(dis);
        if(result == null){
        	label1.setText("����Ĵ����������Ͽⲻ���ڵģ��������ʽ��ȷ�����������룡");
        	label1.setFont(new Font("����", 0, 12));
        	label1.setForeground(Color.red);
        }
        else{       	
            int num = result.length;
            if(num>10){
         	   num = 10;
            }
            imageShow();
        }    
    }
	public void calculate_actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Object target = e.getSource();
	       if (target == calculate)
			try {
				conver();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}		       
	}
	
	public void button_actionPerformed(ActionEvent e,String str){
		display2.setText(str);
	      
	}
	
	 private class WindowCloser extends WindowAdapter {
	       public void windowClosing(WindowEvent we) {
	           System.exit(0);
	       }
	    }
	
	public static void main(String[] args) throws IOException {
		JInput input = new JInput();
		input.input();
	    }
	@Override
	public void actionPerformed(ActionEvent e) {
		String label = e.getActionCommand();		
        str= label;
        button_actionPerformed(e,str);     		  
		display2.setText(str);
	}

}