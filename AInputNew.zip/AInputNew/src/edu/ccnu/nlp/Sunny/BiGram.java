package edu.ccnu.nlp.Sunny;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

public class BiGram {
	//���ӵ�������
	static int sum = 382210;
	public static String[][] biGram(String dis) throws IOException{
		System.out.println("�����ˣ�dis == "+dis);
        PinyinToWord pinyintoword = new PinyinToWord();
        //������Ľ������list��
        List<String> list = pinyintoword.conclude(dis);
        if(list == null){
        	return null;
        }
        //������Ͽ���������Ĵ���Ĵ���������hashmap1��
        HashMap<String,Integer> hashmap1 = ChineseToPinyin.getAllBiWordGroup();
        //�����ʵĴ�Ƶ����hashmap2��
        HashMap<String,Integer> hashmap2 = ChineseToPinyin.getAllWordGroup();     
        //����hashmap1��hashmap2����list����bigramֵ
        String[][] strresult = new String[list.size()][2]; 
        double score;
        for(int i=0;i<list.size();i++){
        	String[] str1 = list.get(i).split("\\s+");
        	double n=0.0,m=0.0;        	
        	score = 0.0;
        	for(int j=1;j<str1.length;j++){
        		if(j == 1 ){
        		   if(hashmap1.containsKey(str1[1])){
        	    		score = (hashmap1.get(str1[1])+1.0)/sum;
        			}
        		}
        		else{
        			if(hashmap1.containsKey(str1[j-1]+" "+str1[j]) &&  hashmap2.containsKey(str1[j])){
        				m = (hashmap1.get(str1[j-1]+" "+str1[j])+1.0);
                    	n = hashmap2.get(str1[j])+sum;
                	    score *= m/n;
                	} 
        			else{
        				if(!hashmap1.containsKey(str1[j-1]+" "+str1[j])&&  hashmap2.containsKey(str1[j])){
        					m = 1.0;
            				n = hashmap2.get(str1[j])+sum;
                    	    score *= m/n;				
        				}
        				else{
                    	    score *= 0.0;	
        				}
        			}
            	}
         	}
            //û�����һ�����ӵķ�ֵ�������Ӻ����ֵ����strresult�С�       
        	strresult[i][0] = list.get(i);
        	strresult[i][1] = Double.toString(score);   
        }       
        //���������              
        for(int i=0;i<strresult.length;i++){
        	for(int j=i;j<strresult.length;j++){
        		if(Double.parseDouble(strresult[i][1]) < Double.parseDouble(strresult[j][1])){
        			String[] st1 = strresult[i]; strresult[i] = strresult[j]; strresult[j] = st1;        			
        		}
        	}
        }   
		return strresult;
   }				
}
