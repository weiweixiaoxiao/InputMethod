package edu.ccnu.nlp.Sunny;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class PinyinToWord {
	static List<String> strlist = new ArrayList<String>();
	private List<String> dieDai( List<String[]> list,String[]arr,String str){
		String str1 = new String();
		for(int i=0;i<list.size();i++){
			if(i == list.indexOf(arr)){		    
				for(String st: arr){
					st = str +" "+ st;
					if(i<list.size()-1){
						dieDai(list,list.get(i+1),st);
					}
					else if(i == list.size()-1){
						str1 = st;
						strlist.add(str1);
					}
				}			
			}
		}
		return strlist;		
	}

	//�磺zhongguo �й� �й����β�������ƴ�������ֵģ��ü���ƴ����һ�����֣�
	private HashMap<String,List<String[]>> pinyinToAllWord(String[][] str) throws IOException{
		HashMap<String,List<String[]>> hashmap2 = new HashMap<String,List<String[]>>();
		for(int i=0;i<str.length;i++){
			String keys[] = str[i][0].split(","); 
			for(String key:keys){
				if(hashmap2.containsKey(key)){
					String[] str1 = new String[2];
					List<String[]> list = new ArrayList<String[]>();
					list = hashmap2.get(key);
					str1[0] = str[i][1];
					str1[1] = str[i][2];
					list.add(str1);	
					hashmap2.put(key, list);
				}
				else{
					String[] str1 = new String[2];
					List<String[]> list = new ArrayList<String[]>();
					str1[0] = str[i][1];
					str1[1] = str[i][2];
					list.add(str1);
					hashmap2.put(key, list);
				}
			}		
		}
		return hashmap2;	
    }
	//���������ƴ��,���������ƥ�䣬Ȼ����������������Ľ��
	private List<String> pinyinToWord(String dis) throws IOException{
		ChineseToPinyin chinesetopinyin = new ChineseToPinyin();
		String[][] str = chinesetopinyin.allChineseToPinyin();
		HashMap<String,List<String[]>> hashmap2 = new HashMap<String,List<String[]>>();
		hashmap2 = pinyinToAllWord(str);
			
		String[] strinput = dis.split("\\s+");
		//������Ľ������list��
		List<String[]> strings = new ArrayList<String[]>();
		for(int i=0;i<strinput.length;i++){
			String key = strinput[i];
			List<String[]> list = new ArrayList<String[]>();			
			list = hashmap2.get(key);
			if(list == null){
				return null;
			}
			String[] s = new String[list.size()];
			for(int j = 0;j<s.length;j++){
				s[j] = list.get(j)[0];
		    }   		   
			strings.add(s);
		}	
		//�������
		List<String> stringresult = new ArrayList<String>();
		if(strings!=null){
			strlist = new ArrayList<String>();
		    stringresult = dieDai(strings, strings.get(0),"");
		}	
		return stringresult;
	}
	//��˽���������ȥ
	public List<String> conclude(String dis) throws IOException {
		   List<String> list = pinyinToWord(dis);
		   if(list == null){
			   return null;
		   }
		   return list;
		}
	
}
