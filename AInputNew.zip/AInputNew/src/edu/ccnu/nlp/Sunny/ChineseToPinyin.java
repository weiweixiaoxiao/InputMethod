package edu.ccnu.nlp.Sunny;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Iterator;

public class ChineseToPinyin {
	//��������е����еĵ�������ʹ���������map��
	public static HashMap<String,Integer> getAllWordGroup() throws IOException{
		@SuppressWarnings("resource")
		BufferedReader br=new BufferedReader(new InputStreamReader(new FileInputStream("E:\\DATA\\NLPCLASS\\�������Ϸִ�.txt"),"UTF-8"));  
		HashMap<String,Integer> map = new HashMap<String,Integer>();
		String line = null;
		while((line = br.readLine())!=null){
			String[] lineone = line.trim().split("\\s+");
			for(int i=0;i<lineone.length;i++){
				if(map.isEmpty() || !map.containsKey(lineone[i])){
					map.put(lineone[i], 1);
				}
				else{
					Integer n = map.get(lineone[i]);
					n = n+1;
					map.put(lineone[i], n);
				}
			}
		}
		return map;		
	}
	
	//��������е����е�����������Ϻʹ���������map��
	public static HashMap<String,Integer> getAllBiWordGroup() throws IOException{
			@SuppressWarnings("resource")
			BufferedReader br=new BufferedReader(new InputStreamReader(new FileInputStream("E:\\DATA\\NLPCLASS\\�������Ϸִ�.txt"),"UTF-8"));  
			HashMap<String,Integer> map = new HashMap<String,Integer>();
			String line = null;
			while((line = br.readLine())!=null){
				String[] lineone = line.trim().split("\\s+");
				String str = lineone[0];
				if(map.isEmpty() || !map.containsKey(str)){
					map.put(str, 1);
				}
				else{
					Integer n = map.get(str);
					n = n+1;
					map.put(str, n);
				}
				for(int i=0;i<lineone.length-1;i++){
					String str0 = lineone[i]+" "+lineone[i+1];
					if(map.isEmpty() || !map.containsKey(str0)){
						map.put(str0, 1);
					}
					else{
						Integer n = map.get(str0);
						n = n+1;
						map.put(str0, n);
					}
				}
			}			
			return map;		
		}
		
	//������תΪƴ��
	public String[][] chineseToPinyin(HashMap<String,Integer> map){
		System.out.println("chineseToPinyin map size"+map.size());
		String[][] string = new String[map.size()][3];	
		Iterator<String> ite = (Iterator<String>) map.keySet().iterator();
		int i = 0;
		while(ite.hasNext()){
			String key = (String)ite.next();	
			string[i][1] = key;
			string[i][2] = map.get(key).toString();
			string[i][0] = pinyin4j.converterToSpell(key);
			i++;
		}
		return string;
	}
	//������תΪƴ��
	public String[][] allChineseToPinyin() throws IOException{
		HashMap<String,Integer> map = getAllWordGroup();
		System.out.println("map == "+map.get("��"));
		String[][] str = new String[map.size()][3];
		str = chineseToPinyin(map);
		return str;	
	}
}
